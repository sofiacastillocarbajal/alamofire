//
//  Character.swift
//  iStarWars
//
//  Created by Gabriela Antezana on 7/4/19.
//  Copyright © 2019 Gabriela Antezana. All rights reserved.
//

import Foundation

struct Character: Codable {
    var name: String?
    var height: String?
    var mass: String?
    var hairColor: String?
    var skinColor: String?
    var eyeColor: String?
    var birthYear: String?
    var gender: String?
    var homeworld: String?
    var created: String?
    var edited: String?
    var url: String?
    
    enum CodingKeys: String, CodingKey {
        case hairColor = "hair_color"
        case skinColor = "skin_color"
        case eyeColor = "eye_color"
        case birthYear = "birth_year"
    }
    
    //var films: [String]?
    //var species: [String]?
    //var vehicles: [String]?
    //var starships: [String]?
    
    var urlToLogo: String {
        return ""
    }
}
