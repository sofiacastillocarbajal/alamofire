//
//  ViewController.swift
//  iStarWars
//
//  Created by Gabriela Antezana on 7/4/19.
//  Copyright © 2019 Gabriela Antezana. All rights reserved.
//

import UIKit

class SettingsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

