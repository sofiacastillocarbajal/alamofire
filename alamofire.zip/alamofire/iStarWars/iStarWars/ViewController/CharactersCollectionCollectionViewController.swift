//
//  CharactersCollectionCollectionViewController.swift
//  iStarWars
//
//  Created by Gabriela Antezana on 7/4/19.
//  Copyright © 2019 Gabriela Antezana. All rights reserved.
//

import UIKit
import os

class CharacterCell: UICollectionViewCell {
    @IBOutlet weak var characterImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    
    func update(from character: Character) {
        //setImage funcion de la extension que descarga la imagen del url dado
        characterImageView.setImage(
            fromUrlString: character.urlToLogo,
            withDefaultImage: "no-image-available",
            withErrorImage: "no-image-available")
        nameLabel.text = character.name
    }
}

private let reuseIdentifier = "CharacterCell"

class CharactersCollectionCollectionViewController: UICollectionViewController {

    var characteres: [Character] = [Character]()
    var currentRow = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        StarWarsApi.getCharacters(responseHandler: handleResponse, errorHandler: handleError)
    }
    
    func handleResponse(response: CharacterResponse) {
        guard let characteres = response.results else {
            self.characteres = [Character]()
            return
        }
        self.characteres = characteres
        self.collectionView.reloadData()
    }
    
    func handleError(error: Error) {
        let message = "Error while requesting Sources: \(error.localizedDescription)"
        os_log("%@", message)
    }

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return characteres.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! CharacterCell
    
        cell.update(from: characteres[indexPath.row])
    
        return cell
    }

    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        currentRow = indexPath.item
    }
    
}
