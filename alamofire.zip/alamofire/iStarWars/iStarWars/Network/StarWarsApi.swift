//
//  StarWarsApi.swift
//  iStarWars
//
//  Created by Gabriela Antezana on 7/4/19.
//  Copyright © 2019 Gabriela Antezana. All rights reserved.
//

import Foundation
import Alamofire
import os

class StarWarsApi {
    static let baseUrlString = "https://swapi.co/api/"
    static let charactersUrlString = "\(baseUrlString)people/"
    
    static private func getCharacterResponse<CharacterResponse: Decodable>(from urlString: String,parameters: [String : String],responseType: CharacterResponse.Type,responseHandler: @escaping ((CharacterResponse) -> Void),errorHandler: @escaping ((Error) -> Void)) {
        //valida url
        guard let url = URL(string: urlString) else {
            let message = "Error on URL"
            os_log("%@", message)
            return
        }
        
        Alamofire.request(url, parameters: parameters).validate().responseJSON(
            completionHandler: { response in
                switch response.result {
                case .success( _):
                    do {
                        let decoder = JSONDecoder()
                        if let data = response.data {
                            let dataResponse = try decoder.decode(responseType, from: data)
                            responseHandler(dataResponse)
                        }
                    } catch {
                        errorHandler(error)
                    }
                    
                case .failure(let error):
                    errorHandler(error)
                }
        })
    }
    
    static func getCharacters(responseHandler: @escaping ((CharacterResponse) -> Void),
                           errorHandler: @escaping ((Error) -> Void)) {
        //se podria omitir parameters
        let parameters = ["key" : "2"]
        self.getCharacterResponse(from: charactersUrlString,parameters: parameters,
                                  responseType: CharacterResponse.self,
                               responseHandler: responseHandler, errorHandler: errorHandler)
    }
    
}
