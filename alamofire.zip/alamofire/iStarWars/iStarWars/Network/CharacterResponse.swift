//
//  CharacterResponse.swift
//  iStarWars
//
//  Created by Gabriela Antezana on 7/4/19.
//  Copyright © 2019 Gabriela Antezana. All rights reserved.
//

import Foundation

struct CharacterResponse : Codable{
    var count: String?
    var next: String?
    var previous: String?
    var results: [Character]?
}
